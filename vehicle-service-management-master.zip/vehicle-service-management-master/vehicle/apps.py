from django.apps import AppConfig


class VehicleConfig(AppConfig):
    name = 'vehicle'
